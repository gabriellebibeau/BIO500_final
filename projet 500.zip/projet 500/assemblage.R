###SCRIPT assemblage

csv_files <- list.files(pattern = "\\.csv$")

data_list <- list()

#Passer au travers de tous les CSV du Fichier et les ouvrir en data.frame
for (file in csv_files) {
  file_path <- file.path(getwd(), file)
  data <- read.csv(file_path, header = TRUE) 
  data_list[[file]] <- data
}

#Combine tous les data.frames dans un seul data.frame
combined_data <- do.call(rbind, data_list)
bd=combined_data

read_d <- function(bd){
  csv_files <- list.files(pattern = "\\.csv$")
  data_list <- list()
  
  for (file in csv_files) {
    file_path <- file.path(getwd(), file)
    data <- read.csv(file_path, header = TRUE)  
    data_list[[file]] <- data
  }
  bd <- do.call(rbind, data_list)
  return(bd) #Retourner la base de données combinées
}

read_d(bd) #Appliquer la fonction pour avoir la base de données