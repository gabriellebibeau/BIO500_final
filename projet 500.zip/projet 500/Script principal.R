### Script principal
# Pour jeu de donnée acoustique_oiseaux
# Travail par Frédérick St-Pierre, Yohan Wegener, Aurel veillet et Félix Labbé

#
setwd(getwd())

# 1) Script d'assemblage des données
source("assemblage.R")
# 3) Script de nettoyage
source("nettoyage.R")
# 2) Script d'ajout d'identifiant tsn
source("assemblage_tsn.R")
# 4) script de validations des données
source("validation.R")
# 5) Visualisation des données modifiées
View(bd)

